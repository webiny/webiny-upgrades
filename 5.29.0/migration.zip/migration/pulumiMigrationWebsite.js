const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const util = require("util");
const ncpBase = require("ncp");
const ncp = util.promisify(ncpBase.ncp);

module.exports = async ({ env, oldPulumiFolderPath, newPulumiFolderPath }) => {
    {
        // Website application.
        console.log(chalk.green(`Migrating Website (apps/website) application's state files...`));

        const oldWebsiteStacksFolderPath = path.join(
            oldPulumiFolderPath,
            `apps/website/.pulumi/stacks`
        );
        const newWebsiteStacksFolderPath = path.join(
            newPulumiFolderPath,
            `apps/website/.pulumi/stacks`
        );

        if (!fs.existsSync(newWebsiteStacksFolderPath)) {
            fs.mkdirSync(newWebsiteStacksFolderPath, { recursive: true });
        }

        await ncp(
            path.join(oldWebsiteStacksFolderPath, `${env}.json`),
            path.join(newWebsiteStacksFolderPath, `${env}.json`)
        );

        await new Promise(resolve => setTimeout(resolve, 500));

        const content = fs.readFileSync(
            path.join(newWebsiteStacksFolderPath, `${env}.json`),
            "utf8"
        );
        const json = JSON.parse(content);

        const websiteResourcesWhitelist = [
            "pulumi:pulumi:Stack",
            "pulumi:providers:aws",
            "aws:cloudfront/distribution:Distribution",
            "aws:s3/bucket:Bucket"
        ];

        json.checkpoint.latest.resources = json.checkpoint.latest.resources.filter(item => {
            return websiteResourcesWhitelist.includes(item.type);
        });

        json.checkpoint.latest.resources = json.checkpoint.latest.resources.map(item => {
            if (item.type === "aws:cloudfront/distribution:Distribution") {
                item.dependencies = item.dependencies.filter(item => {
                    // Remove `WebsiteTenantRouter` from dependencies.
                    return !item  .includes("WebsiteTenantRouter$aws");
                });
            }

            return item;
        });

        const jsonString = JSON.stringify(json, null, 2);

        fs.writeFileSync(path.join(newWebsiteStacksFolderPath, `${env}.json`), jsonString);
    }
};
