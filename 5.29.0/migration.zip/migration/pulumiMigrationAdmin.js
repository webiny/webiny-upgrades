const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const util = require("util");
const ncpBase = require("ncp");
const ncp = util.promisify(ncpBase.ncp);

module.exports = async ({ env, oldPulumiFolderPath, newPulumiFolderPath }) => {
    {
        // Admin application.
        console.log(chalk.green(`Migrating Admin (apps/admin) application's state files...`));

        const oldAdminStacksFolderPath = path.join(
            oldPulumiFolderPath,
            `apps/admin/.pulumi/stacks`
        );
        const newAdminStacksFolderPath = path.join(
            newPulumiFolderPath,
            `apps/admin/.pulumi/stacks`
        );

        if (!fs.existsSync(newAdminStacksFolderPath)) {
            fs.mkdirSync(newAdminStacksFolderPath, { recursive: true });
        }

        await ncp(
            path.join(oldAdminStacksFolderPath, `${env}.json`),
            path.join(newAdminStacksFolderPath, `${env}.json`)
        );

        await new Promise(resolve => setTimeout(resolve, 500));

        const content = fs.readFileSync(path.join(newAdminStacksFolderPath, `${env}.json`), "utf8");
        const json = JSON.parse(content);

        const adminResourcesWhitelist = [
            "pulumi:pulumi:Stack",
            "pulumi:providers:aws",
            "aws:cloudfront/distribution:Distribution",
            "aws:s3/bucket:Bucket"
        ];

        json.checkpoint.latest.resources = json.checkpoint.latest.resources.filter(item => {
            return adminResourcesWhitelist.includes(item.type);
        });

        const jsonString = JSON.stringify(json, null, 2);

        fs.writeFileSync(path.join(newAdminStacksFolderPath, `${env}.json`), jsonString);
    }
};
