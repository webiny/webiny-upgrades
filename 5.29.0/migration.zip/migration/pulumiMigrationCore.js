const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const util = require("util");
const ncpBase = require("ncp");
const ncp = util.promisify(ncpBase.ncp);

module.exports = async ({ env, oldPulumiFolderPath, newPulumiFolderPath }) => {
    console.log(chalk.green(`Migrating Core (apps/core) application's state files...`));

    const oldApiStacksFolderPath = path.join(oldPulumiFolderPath, `api/.pulumi/stacks`);
    const newCoreStacksFolderPath = path.join(newPulumiFolderPath, `apps/core/.pulumi/stacks`);

    if (!fs.existsSync(newCoreStacksFolderPath)) {
        fs.mkdirSync(newCoreStacksFolderPath, { recursive: true });
    }

    await ncp(
        path.join(oldApiStacksFolderPath, `${env}.json`),
        path.join(newCoreStacksFolderPath, `${env}.json`)
    );

    await new Promise(resolve => setTimeout(resolve, 500));

    const content = fs.readFileSync(path.join(newCoreStacksFolderPath, `${env}.json`), "utf8");
    const json = JSON.parse(content);

    const coreResourcesWhitelist = [
        "pulumi:pulumi:Stack",
        "pulumi:providers:aws",
        "aws:cognito/userPool:UserPool",
        "aws:cognito/userPoolClient:UserPoolClient",
        "aws:iam/role:Role",
        "aws:dynamodb/table:Table",
        "aws:s3/bucket:Bucket",
        "aws:iam/rolePolicyAttachment:RolePolicyAttachment",
        "aws:iam/policy:Policy",
        "aws:lambda/function:Function",
        "aws:elasticsearch/domain:Domain",
        "aws:lambda/eventSourceMapping:EventSourceMapping",
        "aws:elasticsearch/domainPolicy:DomainPolicy"
    ];

    json.checkpoint.latest.resources = json.checkpoint.latest.resources.filter(item => {
        if (!coreResourcesWhitelist.includes(item.type)) {
            return false;
        }

        switch (item.type) {
            case "aws:lambda/function:Function":
                return item.id.startsWith("dynamo-to-elastic");
            case "aws:iam/role:Role":
                return item.id.startsWith("dynamo-to-elastic");
            case "aws:iam/policy:Policy":
                return item.id.includes("DynamoDbToElastic");
            case "aws:iam/rolePolicyAttachment:RolePolicyAttachment":
                return item.id.startsWith("dynamo-to-elastic");
            default:
                return true;
        }
    });

    let jsonString = JSON.stringify(json, null, 2);

    jsonString = jsonString.replace(new RegExp(`api-${env}`, "g"), `core-${env}`);
    jsonString = jsonString.replace(new RegExp(`${env}::api`, "g"), `${env}::core`);

    fs.writeFileSync(path.join(newCoreStacksFolderPath, `${env}.json`), jsonString);
};
