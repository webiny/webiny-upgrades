const fs = require("fs");
const path = require("path");
const chalk = require("chalk");
const util = require("util");
const ncpBase = require("ncp");
const ncp = util.promisify(ncpBase.ncp);

module.exports = async ({ env, oldPulumiFolderPath, newPulumiFolderPath }) => {
    // Api application.
    console.log(chalk.green(`Migrating Api (apps/api) application's state files...`));


    const oldApiStacksFolderPath = path.join(oldPulumiFolderPath, `api/.pulumi/stacks`);
    const newApiStacksFolderPath = path.join(newPulumiFolderPath, `apps/api/.pulumi/stacks`);

    if (!fs.existsSync(newApiStacksFolderPath)) {
        fs.mkdirSync(newApiStacksFolderPath, { recursive: true });
    }

    await ncp(
        path.join(oldApiStacksFolderPath, `${env}.json`),
        path.join(newApiStacksFolderPath, `${env}.json`)
    );

    await new Promise(resolve => setTimeout(resolve, 1000));

    const stateFilePath = path.join(process.cwd(), newApiStacksFolderPath, `${env}.json`);
    const content = fs.readFileSync(stateFilePath, "utf8");

    const json = JSON.parse(content);

    const apiResourcesWhitelist = [
        "pulumi:pulumi:Stack",
        "pulumi:providers:aws",
        "aws:cloudfront/distribution:Distribution"
    ];

    json.checkpoint.latest.resources = json.checkpoint.latest.resources.filter(item => {
        return apiResourcesWhitelist.includes(item.type);
    });

    json.checkpoint.latest.resources = json.checkpoint.latest.resources.map(item => {
        if (item.type === "aws:cloudfront/distribution:Distribution") {
            item.dependencies = [];
        }

        return item;
    });

    const jsonString = JSON.stringify(json, null, 2);

    fs.writeFileSync(path.join(newApiStacksFolderPath, `${env}.json`), jsonString);
};
