const { argv } = require("yargs");

const env = argv.env;
const oldPulumiFolderPath = argv.oldPulumiFolderPath;
const newPulumiFolderPath = argv.newPulumiFolderPath;

if (!env) {
    throw new Error("--env not specified.");
}

if (!oldPulumiFolderPath) {
    throw new Error("--old-pulumi-folder-path not specified.");
}

if (!newPulumiFolderPath) {
    throw new Error("--new-pulumi-folder-path not specified.");
}

(async () => {
    const core = require("./pulumiMigrationCore");
    await core({ env, oldPulumiFolderPath, newPulumiFolderPath });

    const api = require("./pulumiMigrationApi");
    await api({ env, oldPulumiFolderPath, newPulumiFolderPath });

    const admin = require("./pulumiMigrationAdmin");
    await admin({ env, oldPulumiFolderPath, newPulumiFolderPath });

    const website = require("./pulumiMigrationWebsite");
    await website({ env, oldPulumiFolderPath, newPulumiFolderPath });
})();
